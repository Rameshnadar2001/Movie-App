import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { UserServiceService } from '../services/user-service.service';
import { AuthServiceService } from '../services/auth-service.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { FavoriteMoviesComponent } from '../favorite-movies/favorite-movies.component';
import { Movie } from '../models/Movie';

@Component({
  selector: 'app-movie-card',
  templateUrl: './movie-card.component.html',
  styleUrls: ['./movie-card.component.css'],
})
export class MovieCardComponent implements OnInit {
  @Input() movie?: any;
  @Input() genresss: any[] = [];
  @Input() isFavoriteMovie?: boolean;
  @Output() onDelete: EventEmitter<Movie> = new EventEmitter<Movie>();
  movieGenres: string[] = [];
  isHovered: boolean = false;

  genre_names: string = '';
  constructor(
    private userService: UserServiceService,
    private authService: AuthServiceService,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    // console.log(this.genresss);
    console.log('GENREIDs OF THIS MOVIE ' + this.movie.genre_ids);
    for (let genre of this.genresss) {
      for (let g of this.movie.genre_ids) {
        if (g == genre.id) {
          // console.log(genre.name);
          this.movieGenres.push(genre.name);
        }
      }
    }
    this.genre_names = this.movieGenres.join(',');
    //  console.log(this.genre_names);
  }

  test() {
    // console.log(this.movie);
    // console.log(this.movieGenres);
  }
  addToFavorites(movie: any) {
    this.userService.addToFavoriteMovies(movie).subscribe({
      next: (data) => {
        console.log(data);
        this.snackBar.open('Added to favorites', 'success', {
          duration: 3000,
          panelClass: ['mat-toolbar', 'mat-primary'],
        });
        // this.favoriteMovie.getFavoriteMovies();
      },
      error: (error) => {
        alert(error.error);
      },
    });
  }

  deleteFromFavorite(id: number) {
    this.userService.deleteMovieFromFavorite(id).subscribe({
      next: (data) => {
        this.onDelete.emit(this.movie);
        this.snackBar.open('Removed from favorites', 'success', {
          duration: 3000,
          panelClass: ['mat-toolbar', 'mat-primary'],
        });
      },
      error: (error) => {
        alert(error.error);
      },
    });
  }

  buttonVisibility() {
    console.log("hovered")
    this.isHovered = true;
  }
  onMouseLeave() {
    this.isHovered = false;
  }
}
