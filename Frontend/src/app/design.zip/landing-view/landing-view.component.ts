import { Component, HostListener, OnInit } from '@angular/core';
import { MovieRecommendationService } from '../services/movie-recommendation.service';


@Component({
  selector: 'app-landing-view',
  templateUrl: './landing-view.component.html',
  styleUrls: ['./landing-view.component.css']
})
export class LandingViewComponent implements OnInit {



  mov:any;
  movies:any[]=[];
  newMovies:any[]=[];
  genres:any[]=[];
  movieSearch:string='';
  langByChip:string='';
  currentPage:number=0;
  nextPage:number=0;
  prevPage:number=0;
  totalPage:number=0;
  genreSelection:string='';


  constructor(private movieService:MovieRecommendationService) { }

  ngOnInit(): void {
   
  this.getAllMovies(); 
}

sortByGenre() {
  console.log("Genre Selection::"+this.genreSelection.length);
  if(this.langByChip.length){
     if(this.genreSelection.length){
       this.movieService.getMoviesByGenreAndLang(this.langByChip,this.genreSelection).subscribe({
         next:data=>{
           console.log(data.results);
           this.movies=data.results;
           this.currentPage=data.page;
           this.nextPage=this.currentPage+1;
           // this.prevPage=this.currentPage-1;
           this.totalPage=data.total_pages
         }
        })
     }
     else{
       this.movieService.getMoviesByLang(this.langByChip).subscribe({
         next:data=>{
           console.log(data);
           this.movies=data.results;
           this.currentPage=data.page;
           this.nextPage=this.currentPage+1;
           // this.prevPage=this.currentPage-1;
           this.totalPage=data.total_pages
           console.log("totalPage lang ::"+this.totalPage)
           console.log("page lang::"+this.currentPage)
           console.log("nextPage lang::"+this.nextPage)
           console.log("prevPage lang::"+this.prevPage)
         }
     })
   }
}else if(this.genreSelection.length){
    this.movieService.getMoviesByGenre(this.genreSelection).subscribe({
      next:data=>{
        console.log(data.results);
        this.movies=data.results;
        this.currentPage=data.page;
          this.nextPage=this.currentPage+1;
          // this.prevPage=this.currentPage-1;
          this.totalPage=data.total_pages
      }
  })
}
else{
  this.getAllMovies();
}
}

  getAllMovies(){
    this.movieService.getMovies().subscribe({
      next:data=>{
        console.log(data);
         this.mov=data;
         console.log("RESUL::"+this.mov.results);
         this.movies=this.mov.results;
         this.currentPage=this.mov.page;
         this.nextPage=this.currentPage+1;
         this.prevPage=this.currentPage-1;
         this.totalPage=this.mov.total_pages
         console.log("totalPage ::"+this.totalPage)
         console.log("page ::"+this.currentPage)
         console.log("nextPage ::"+this.nextPage)
         console.log("prevPage ::"+this.prevPage)
      },
      error:error=>{
        alert('Failed to Fetch Notes Due to Server Error !!');
      }

    });
    this.getAllGenres();
  }

  
  getAllGenres(){
    this.movieService.getGenres().subscribe({
      next:data=>{
        this.genres=data;
      //  console.log(this.genres);
      },
      error:error=>{
        alert('Failed to Fetch Notes Due to Server Error !!');
      }
    })
  }



  searchMovie($event:string){
    this.movieSearch=$event
    if(this.movieSearch.length){
      this.movieService.getSearchedMovies(this.movieSearch).subscribe({//page
        next:data=>{
          this.mov=data;
          // console.log(this.mov.results);
          this.movies=this.mov.results
        }
      })
    }else{
      this.getAllMovies();
    }
  }

  
  filterByLang($event:string) {
    this.langByChip=$event;
    console.log(this.langByChip);
    if(this.langByChip.length){
      this.movieService.getMoviesByLang(this.langByChip).subscribe({
        next:data=>{
          console.log(data);
          this.movies=data.results;
          this.currentPage=data.page;
          this.nextPage=this.currentPage+1;
          // this.prevPage=this.currentPage-1;
          this.totalPage=data.total_pages
          console.log("totalPage lang ::"+this.totalPage)
          console.log("page lang::"+this.currentPage)
          console.log("nextPage lang::"+this.nextPage)
          console.log("prevPage lang::"+this.prevPage)
        }
      })
    }else{
      this.getAllMovies();
    }
    
  }



@HostListener('window:scroll', ['$event'])
onScroll(event:Event):void{
  const scrollPosition=window.scrollY+window.innerHeight;
  const documentHeight=document.documentElement.scrollHeight;
  if(scrollPosition>=documentHeight-200){
   this.next();
  }
}


  next(){
    if(this.nextPage<=this.totalPage){
     if(this.langByChip.length){
       if(this.genreSelection.length){
         
        this.movieService.getMoviesByGenreAndLangWithPage(this.langByChip,this.genreSelection,this.nextPage)
        .subscribe({
          next:data=>{
            this.currentPage=data.page;
           
            this.newMovies = data.results.filter((newMovie:any)=> !this.movies.some(existingMovie => existingMovie.id === newMovie.id));
            console.log("new Movie::"+this.newMovies);
            console.log(this.newMovies);
            this.movies=[...this.movies,...this.newMovies];
            this.nextPage=this.currentPage+1;
            // this.prevPage=this.currentPage-1;
            this.totalPage=data.total_pages
          }
        })
      }else{
        this.loadMoviesByLangAndPage();
       }
    }else if(this.genreSelection.length){
      this.movieService.getMoviesByGenreWithPage(this.genreSelection,this.nextPage).subscribe({
        next:data=>{
          this.currentPage=data.page;
          this.newMovies = data.results.filter((newMovie:any)=> !this.movies.some(existingMovie => existingMovie.id === newMovie.id));
          console.log("new Movie::"+this.newMovies);
          console.log(this.newMovies);
          this.movies=[...this.movies,...this.newMovies];
          this.nextPage=this.currentPage+1;
          // this.prevPage=this.currentPage-1;
          this.totalPage=data.total_pages
        }
      })
    }else{
        this.movieService.getMoviesBypage(this.nextPage).subscribe({
         next:data=>{
          console.log(data.results);
          this.currentPage=data.page;
          this.newMovies = data.results.filter((newMovie:any)=> !this.movies.some(existingMovie => existingMovie.id === newMovie.id));
          console.log("new Movie::"+this.newMovies);
          this.movies=[...this.movies,...this.newMovies];
          this.nextPage=this.currentPage+1;
          // this.prevPage=this.currentPage-1;
          this.totalPage=data.total_pages
          console.log("totalPage in else ::"+this.totalPage)
          console.log("page in else::"+this.currentPage)
          console.log("nextPage in else::"+this.nextPage)
          console.log("prevPage in else::"+this.prevPage)
        }
      })
    }
  }
}

  // previous(){
  //   if(this.prevPage>0){
  //     if(this.langByChip.length){
  //       this.movieService.getMoviesByLangAndPage(this.langByChip,this.prevPage).subscribe({
  //        next:data=>{
  //          console.log(data.results);
  //          this.movies=data.results;
  //          this.currentPage=data.page;
  //          this.nextPage=this.currentPage+1;
  //          this.prevPage=this.currentPage-1;
  //          this.totalPage=data.total_pages;
  //          console.log("totalPage in next ::"+this.totalPage)
  //          console.log("page in next::"+this.currentPage)
  //          console.log("nextPage in next::"+this.nextPage)
  //          console.log("prevPage in next::"+this.prevPage)
  //        }
  //       })
  //     }else{
  //      this.movieService.getMoviesBypage(this.prevPage).subscribe({
  //         next:data=>{
  //          console.log(data.results);
  //          this.currentPage=data.page;
  //          this.movies=data.results;
  //          this.nextPage=this.currentPage+1;
  //          this.prevPage=this.currentPage-1;
  //          this.totalPage=data.total_pages
  //          console.log("totalPage in else ::"+this.totalPage)
  //          console.log("page in else::"+this.currentPage)
  //          console.log("nextPage in else::"+this.nextPage)
  //          console.log("prevPage in else::"+this.prevPage)
  //        }
  //      })
  //     }
  //    }

  // }

  getAllMoviesByGenres(){
    
  }

 loadMoviesByLangAndPage(){
  this.movieService.getMoviesByLangAndPage(this.langByChip,this.nextPage).subscribe({
    next:data=>{
      console.log(data.results);
      this.newMovies = data.results.filter((newMovie:any)=> !this.movies.some(existingMovie => existingMovie.id === newMovie.id));
      console.log("new Movie::");
      console.log(this.newMovies);
      this.movies=[...this.movies,...this.newMovies];
      this.currentPage=data.page;
      this.nextPage=this.currentPage+1;
      // this.prevPage=this.currentPage-1;
      this.totalPage=data.total_pages;
      console.log("totalPage in next ::"+this.totalPage)
      console.log("page in next::"+this.currentPage)
      console.log("nextPage in next::"+this.nextPage)
      // console.log("prevPage in next::"+this.prevPage)
    }
   })
 }


}
